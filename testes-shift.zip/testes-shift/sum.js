const jestConfig = {
  verbose: true,
  testURL: "https://corona.lmao.ninja",
  'transform': {
    '^.+\\.jsx?$': 'babel-jest',
  },
  testMatch: ['**/__tests__/*.js?(x)'],
}

module.exports = jestConfig