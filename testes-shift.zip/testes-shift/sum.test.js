const request = require("supertest");
const ApiUrl = "https://corona.lmao.ninja";

      describe("GET /v3/covid-19/countries", () => {
        it("should return 200 and check countries'", () => {
              return request(ApiUrl)
              .get("/v3/covid-19/countries")
              .expect(200)
              .then(response => {
                expect.arrayContaining()
                console.log(response.body);
              });
          });
      });

      describe("GET /v3/covid-19/countries/Brazil", () => {
        it("should return 200 and check Brazil'", () => {
              return request(ApiUrl)
              .get("/v3/covid-19/countries/Brazil")
              .expect(200)
              .then(response => {
                // expect.arrayContaining()
                // console.log(response.body);
                for (var i = 0; i < response.body.length; i++) {
                    expect(response.body[i].updated).toBeDefined();
                    expect(response.body[i].country).toMatch(/^(Brazil).*/)
                    for (var i = 0; i < response.body.countryInfo.length; i++) {
                      expect(response.body[i]._id).toBe(76);
                      expect(response.body[i].iso2).toMatch(/^(BR).*/)
                      expect(response.body[i].iso3).toMatch(/^(BRA).*/)
                      expect(response.body[i].lat).toBe(-5);
                      expect(response.body[i].long).toBe(-55);
                      expect(response.body[i].flag.image).toContain("https://disease.sh/assets/img/flags/br.png");
                   }  
                   
                 }   
              });
          });
      });

    it("should return 404 with 'The countries was not found'", () => {});
